<div align="center">

![inspireNuggets](https://res.cloudinary.com/iambeejayayo/image/upload/v1544624001/tab-icon.png)

A Chrome Extension that generates random inspiring techie quotes for developers/designers. :fire:

[![made in nigeria](https://img.shields.io/badge/made%20in-nigeria-008751.svg?style=for-the-badge)](https://github.com/acekyd/made-in-nigeria)

![Extension Demo](https://res.cloudinary.com/iambeejayayo/image/upload/v1544623688/inspire.gif)

</div>
