<div align="center">

![inspireNuggets](/tab-icon.png)

A Chrome Browser Extension that displays random inspiring techie quotes for developers/designers. :fire:

[![Awesome](https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg)](https://github.com/sindresorhus/awesome)

[![made in nigeria](https://img.shields.io/badge/made%20in-nigeria-008751.svg?style=for-the-badge)](https://github.com/acekyd/made-in-nigeria)


Download <img src="https://raw.githubusercontent.com/alrra/browser-logos/master/src/chrome/chrome_48x48.png" width="15" /></a> Extension [here](https://chrome.google.com/webstore/detail/inspirenuggets-for-chrome/acnfgdioohhajabdofaadfdhmlkphmlb)

Submit a/your Quote [here](https://goo.gl/forms/a7F16zmOKFCCw6483)

Contributor's Guide [here](https://github.com/BolajiAyodeji/inspireNuggets/blob/master/docs/README.md)

![Extension Demo](https://res.cloudinary.com/iambeejayayo/image/upload/v1566247226/inspireNuggets/demo.gif "Extension Demo")

</div>


## Author
[Bolaji Ayodeji](https://github.com/BolajiAyodeji)

## Licence
[MIT](https://opensource.org/licenses/MIT)
